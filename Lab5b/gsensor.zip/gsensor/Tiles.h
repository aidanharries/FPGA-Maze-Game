int tiles [786];

void DrawTiles(void *virtual_base);

int TileCollision(int *Player_x, int *Player_y, void *virtual_base);